// script.js
document.getElementById('quickBuyBtn').addEventListener('click', () => {
    const message = 'Todos os itens foram adicionados ao carrinho! / ¡Todos los artículos han sido agregados al carrito!';
    document.getElementById('purchaseMessage').innerText = message;
    alert(message);
});
