# Landing Page - BASF 

Este projeto é uma landing page desenvolvida para apresentar as baterias NAS®, que são projetadas para armazenamento de energia estacionário com características superiores de segurança e desempenho.

## Tecnologias Utilizadas

- HTML5
- CSS3
- JavaScript
- Imagens (PNG, JPEG)
- Fontes personalizadas

## Estrutura do Projeto

/BASF (raiz do projeto)
    -/css (Pasta de css)
        -style.css
    
    -/js (Pasta de JS)
        -script.js
    
    -/images (Pasta de imagens e ícones)
        - # Todas as Imagens e ícones do projeto 
    
    -/favicon_io (Pasta para ícones para o navegador)
        - # Ícones para diversos tamanhos de tela
    
-Desafio_Estagio_Plataformas_BASF.pdf

-index.html

-README.md

